package ex03_wild_farm;

public abstract class Feline extends Mammal{
    public Feline(String animalName, String animalType, double animalWeight, String livingRegion){
        super(animalName, animalType, animalWeight, livingRegion);
    }
}
