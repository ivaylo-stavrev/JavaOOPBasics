package ex03_wild_farm;

public class Meat extends Food{
    public static final String FOOD_TYPE_MEAT = "Meat";

    public Meat(int quantity) {
        super(quantity, FOOD_TYPE_MEAT);
    }
}
