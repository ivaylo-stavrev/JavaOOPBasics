package lab03_shapes;

public class Main {
}
