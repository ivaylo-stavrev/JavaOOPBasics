package ex02_multiple_implementation;

public interface Birthable {
    String getBirthdate();
}
