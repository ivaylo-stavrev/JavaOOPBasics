package ex02_multiple_implementation;

public interface Identifiable {
    String getId();
}
