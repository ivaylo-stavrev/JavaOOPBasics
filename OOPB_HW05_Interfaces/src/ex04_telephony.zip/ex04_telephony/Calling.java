package ex04_telephony;

public interface Calling {
    void call(String number);
}
