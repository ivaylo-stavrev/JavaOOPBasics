package ex04_telephony;

public interface Browsing {
    void browse(String url);
}
