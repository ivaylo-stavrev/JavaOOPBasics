package ex07_food_shortage;

public interface Buyer {
    int DEFAULT_FOOD = 0;
    void buyFood();
    int getFood();
}
