package ex07_food_shortage;

public interface Indexable {
    String getId();
}
