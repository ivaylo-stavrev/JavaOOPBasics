package ex07_food_shortage;

public interface Bornable {
    String getName();
    String getBirthDate();
}
