package ex08_military_elite;

public interface ISpecialisedSoldier extends IPrivate {
    String getCorps();
}
