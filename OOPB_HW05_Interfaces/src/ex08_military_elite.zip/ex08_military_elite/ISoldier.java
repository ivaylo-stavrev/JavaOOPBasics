package ex08_military_elite;

public interface ISoldier {
    String getFirstName();
    String getLastName();
    String getId();
}
