package ex08_military_elite;

import java.util.Set;

public interface ICommando extends ISpecialisedSoldier {
    Set<Mission> getMissions();
}
