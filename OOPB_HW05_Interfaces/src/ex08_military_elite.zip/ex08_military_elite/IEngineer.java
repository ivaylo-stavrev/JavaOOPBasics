package ex08_military_elite;

import java.util.Set;

public interface IEngineer extends ISpecialisedSoldier {
    Set<Repair> getRepairs();
}
