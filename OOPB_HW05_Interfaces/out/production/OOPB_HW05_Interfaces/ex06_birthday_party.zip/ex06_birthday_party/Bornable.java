package ex06_birthday_party;

public interface Bornable {
    String getName();
    String getBirthDate();
}
