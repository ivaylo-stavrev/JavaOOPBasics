package ex06_birthday_party;

public interface Indexable {
    String getId();
}
