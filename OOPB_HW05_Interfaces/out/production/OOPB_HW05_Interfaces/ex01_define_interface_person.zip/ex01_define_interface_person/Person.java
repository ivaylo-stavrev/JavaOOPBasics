package ex01_define_interface_person;

public interface Person {
    //String name = "";
    //int age = 0;

    String getName();
    int getAge();

}
