package ex03_ferrari;

public interface Pushable {
    void pushTheGasPedal();
}
