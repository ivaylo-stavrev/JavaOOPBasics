package ex03_ferrari;

public interface Stoppable {
    void breaks();
}
