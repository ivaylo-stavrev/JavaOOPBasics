package ex05_border_control;

public interface Indexable {
    String getId();
}
