package ex08_military_elite;

public interface IMission {
    void CompleteMission();
}
