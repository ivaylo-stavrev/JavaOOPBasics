package ex08_military_elite;

public interface ISpy extends ISoldier {
    String getCodeNumber();
}
