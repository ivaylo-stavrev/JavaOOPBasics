package ex08_military_elite;

public interface IRepair {
    String getPartName();
    int getHoursWorked();
}
