package ex08_military_elite;

import java.util.Set;

public interface ILeutenantGeneral extends IPrivate {
    Set<Private> getPrivates();
}
