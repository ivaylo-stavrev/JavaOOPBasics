import engines.WarManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        WarManager warManager = new WarManager();

        String line = reader.readLine();
        while (true) {
            if ("WAR_IS_OVER".equals(line)) {
                break;
            }
            String[] lineSplitted = line.split("\\s+");

            String command = lineSplitted[0];
            String name = lineSplitted[1];
            if(lineSplitted.length > 2) {
                String argument1 = lineSplitted[2];
            }
            if(lineSplitted.length > 3) {
                String energy = lineSplitted[3];
                String health = lineSplitted[4];
                int intelligence = Integer.parseInt(lineSplitted[5]);
                String argument2 = lineSplitted[6];
            }

            switch (command) {
                case "CHECK_CHARACTER":
                    warManager.checkComicCharacter(name);
                    break;
                case "REGISTER_HERO":
                    break;
                case "REGISTER_ANTI_HERO":
                    break;
                case "BUILD_ARENA":
                    break;
                case "SEND_HERO":
                    break;
                case "SEND_ANTI_HERO":
                    break;
                case "SUPER_POWER":
                    break;
                case "ASSIGN_POWER":
                    break;
                case "UNLEASH":
                    break;
                case "COMICS_WAR":
                    break;
            }

            line = reader.readLine();
        }
    }
}
