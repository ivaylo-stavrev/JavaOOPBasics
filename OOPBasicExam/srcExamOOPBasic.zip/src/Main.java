import engines.WarManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        WarManager warManager = new WarManager();

        String line = reader.readLine();
        while (true) {
            if ("WAR_IS_OVER".equals(line)) {
                break;
            }
            String[] lineSplitted = line.split("\\s+");

            String arg0 = lineSplitted[0];
            String arg1 = lineSplitted[1];
            int arg2 = Integer.parseInt(lineSplitted[2]);

            // Enter logic here ...

            line = reader.readLine();
        }
    }
}
