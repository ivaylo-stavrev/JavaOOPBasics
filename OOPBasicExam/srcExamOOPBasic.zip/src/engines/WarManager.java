package engines;

import contracts.Arena;
import contracts.ComicCharacter;
import contracts.SuperPower;
import contracts.WarManagerIF;

import java.util.*;

public class WarManager implements WarManagerIF {

    private Map<String, ComicCharacter> allCharacters;
    private Map<String, ComicCharacter> allHeroes;
    private Map<String, ComicCharacter> allAntiHeroes;
    private Map<String, Arena> arenas;
    private Map<String, SuperPower> allAvailablePowers;

    public WarManager(Map<String, ComicCharacter> allHeroes, Map<String, ComicCharacter> allAntiHeroes) {
        this.allHeroes = new HashMap<>();
        this.allAntiHeroes = new HashMap<>();
    }

    public WarManager() {
        this.allCharacters = new LinkedHashMap<>();
        this.allHeroes = new LinkedHashMap<>();
        this.allAntiHeroes = new LinkedHashMap<>();
        this.arenas = new LinkedHashMap<>();
        this.allAvailablePowers = new LinkedHashMap<>();
    }

    @Override
    public String checkComicCharacter(String characterName) {

        String result = "";
        //allCharacters.putAll(allHeroes);
        //allCharacters.putAll(allAntiHeroes);
        if(!allCharacters.containsKey(characterName)) {
            result = String.format("Sorry, fans! %s doesn't exist in our comics!", characterName);
        } else {
            if (allCharacters.get(characterName).getHealth() <= 0) {
                result = String.format("%s has fallen in battle!", characterName);
            }
        }
        return result;
    }

    @Override
    public String addHero(ComicCharacter hero) {
        if(allHeroes.get(hero.getName()) == hero) {
            allHeroes.get(hero.getName()).boostCharacter(hero.getEnergy(), hero.getHealth(), hero.getIntelligence());
            return String.format("%s evolved!", hero.getName());
        } else {
            allHeroes.put(hero.getName(), hero);
            allCharacters.put(hero.getName(), hero);
            return String.format("%s is ready for battle!", hero.getName());
        }
    }

    @Override
    public String addAntiHero(ComicCharacter antiHero) {
        if(allAntiHeroes.get(antiHero.getName()) == antiHero) {
            allAntiHeroes.get(antiHero.getName()).boostCharacter(antiHero.getEnergy(), antiHero.getHealth(), antiHero.getIntelligence());
            return String.format("%s is getting stronger!", antiHero.getName());
        } else {
            allAntiHeroes.put(antiHero.getName(), antiHero);
            allCharacters.put(antiHero.getName(), antiHero);
            return String.format("%s is ready for destruction!", antiHero.getName());
        }
    }

    @Override
    public String addArena(Arena arena) {
        if(this.arenas.containsKey(arena)) {
            return "A battle is about to start there!";
        } else {
            return String.format("%s is becoming a fighting ground!", arena.getArenaName());
        }
    }

    @Override
    public String addHeroToArena(String arena, String hero) {
        if(allHeroes.get(hero).isCurrentlyOnArena()) {
            return String.format("%s is fighting!", hero);
        } else if(allHeroes.get(hero).getHealth() <= 0) {
            return String.format("%s is dead!", hero);
        } else if(arenas.get(arena).isArenaFull()) {
            return "Arena is full!";
        } else {
            arenas.get(arena).addHero(allHeroes.get(hero));
            return String.format("%s is fighting for your freedom in %s!", hero, arena);
        }
    }

    @Override
    public String addAntiHeroToArena(String arena, String antiHero) {
        if(allHeroes.get(antiHero).isCurrentlyOnArena()) {
            return String.format("%s is fighting!", antiHero);
        } else if(allHeroes.get(antiHero).getHealth() <= 0) {
            return String.format("%s is dead!", antiHero);
        } else if(arenas.get(arena).isArenaFull()) {
            return "Arena is full!";
        } else {
            arenas.get(arena).addHero(allHeroes.get(antiHero));
            return String.format("%s and his colleagues are trying to take over %s!", antiHero, arena);
        }
    }

    @Override
    public String loadSuperPowerToPool(SuperPower superPower) {
        if(allAvailablePowers.containsKey(superPower)) {
            return "This super power already exists!";
        } else {
            allAvailablePowers.put(superPower.getName(), superPower);
            return String.format("%s added to pool!", superPower.getName());
        }
    }

    @Override
    public String assignSuperPowerToComicCharacter(String comicCharacter, String superPower) {
        if(!allAvailablePowers.containsKey(superPower)) {
            return String.format("%s already assigned!", superPower);
        } else {
            //allCharacters.values()
            //        .stream()
            //        .filter(hero -> hero.getName().equals(comicCharacter))
            //        .forEach(hero -> hero.addSuperPower(allAvailablePowers.get(superPower)));
            for (ComicCharacter character : allCharacters.values()) {
                if(character.getName().equals(comicCharacter)) {
                    character.addSuperPower(allAvailablePowers.get(superPower));
                    break;
                }
            }
            allAvailablePowers.remove(superPower);
            return String.format("%s has a new super power!", comicCharacter);
        }
    }

    @Override
    public String usePowers(String characterName) {
        //if(allCharacters.get(characterName).getPowers().size() == 0) {
        //    return String.format("%s has no super powers!", characterName);
        //} else {
        //    allCharacters.get(characterName).useSuperPowers();
        //    return String.format("%s used his super powers!", characterName);
        //}
        return allCharacters.get(characterName).useSuperPowers();
    }

    @Override
    public String startBattle(String arena) {
        return null;
    }

    @Override
    public String endWar() {
        return null;
    }
}
