package models.characters;

public class Khajiit extends Strength {
    public Khajiit(String name, int magicka, int fatigue, int health) {
        super(name, magicka, fatigue, health, "KHAJIIT");
    }
}
