package ex05_online_radio_database;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int numOfSongs = 0;
        int numOfInputs = Integer.parseInt(reader.readLine());
        List<Song> Songs = new LinkedList<>();


        for (int i = 0; i < numOfInputs; i++) {
            Song song = null;
            String[] lineSplitted = reader.readLine().split(";");

            String artist = lineSplitted[0];
            String title = lineSplitted[1];
            String[] songLength = lineSplitted[2].split(":");
            int minutes = Integer.parseInt(songLength[0]);
            int seconds = Integer.parseInt(songLength[1]);
            // Enter logic here ...

            try {
                song = new Song(artist, title, minutes, seconds);
                if (song != null) {
                    Songs.add(song);
                    System.out.println("Song added.");
                    numOfSongs++;
                }
            } catch (InvalidSongException ise) {
                System.out.println(ise.getMessage());
            }
        }


        System.out.printf("Songs added: %d%n", numOfSongs);

        int allHours = 0;
        int allMinutes = 0;
        int allSeconds = 0;
        for (Song song : Songs) {
            allSeconds += song.getSeconds();
            if(allSeconds > 59) {
                allSeconds -= 60;
                allMinutes += song.getMinutes() + 1;
            }
            else {
                allMinutes += song.getMinutes();
            }
            if(allMinutes > 59) {
                allHours += 1;
                allMinutes -= 60;
            }
        }
        System.out.printf("Playlist length: %dh %dm %ds", allHours, allMinutes, allSeconds);
    }
}
